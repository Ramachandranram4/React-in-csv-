// src/App.js
import React from 'react';
import DatasetUploader from './components/DatasetUploader';

const App = () => {
  const handleDatasetUpload = (file) => {

    console.log('File to upload:', file);
  };

  return (
    <div style={appStyles}>
      <h1 style={headerStyles}>Data Sets</h1>
      <DatasetUploader onUpload={handleDatasetUpload} />
      {}
    </div>
  );
};

const appStyles = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  minHeight: '100vh', 
  backgroundColor: 'lightblue', 
};

const buttonStyles = {
  backgroundColor: '#007BFF',
  color: '#fff',
  padding: '10px 20px',
  borderRadius: '20px', 
  cursor: 'pointer',
  border: 'none',
  outline: 'none',
};
const headerStyles = {
  fontSize: '2rem',
  marginBottom: '20px',
};

export default App;
